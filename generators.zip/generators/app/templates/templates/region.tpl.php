<?php

/**
 * @file
 * theme implementation to display a region.
 * Should not be wrapped by default.
 *
 * Available variables:
 * for info on available variables see modules/system/region.tpl.php
 *
 * @see template_preprocess()
 * @see template_preprocess_region()
 * @see template_process()
 */
?>

<?php print $content; ?>
